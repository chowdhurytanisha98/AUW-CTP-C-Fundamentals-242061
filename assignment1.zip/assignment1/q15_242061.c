#include <cs50.h>
#include <stdio.h>

int main()
{
    for (int i = 1; i <= 19; i += 2)
    {
        printf("%d\n", i);
    }
    return 0;
}
